import React from 'react';
import { Store, User, Plus, History, ChevronRight, ArrowLeft } from 'lucide-react';
import { StaffSummary } from '../types';

interface MenuPageProps {
  staff: StaffSummary | null;
  onResume: () => void;
  onNew: () => void;
  onHistory: () => void;
  onBack: () => void;
}

export const MenuPage: React.FC<MenuPageProps> = ({ staff, onResume, onNew, onHistory, onBack }) => {
  if (!staff) return null;
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-md w-full overflow-hidden">
        <div className="bg-blue-900 p-6 text-white relative">
          <button onClick={onBack} className="absolute left-4 top-4 hover:bg-blue-800 p-2 rounded-full transition-colors">
            <ArrowLeft size={24} />
          </button>
          <div className="mt-8 text-center">
            <h2 className="text-2xl font-bold mb-1">{staff.name}</h2>
            <p className="text-blue-200 text-sm flex items-center justify-center gap-1">
              <Store size={14} /> {staff.store}
            </p>
          </div>
        </div>
        <div className="p-6 space-y-4">
          <button onClick={onResume} className="w-full bg-blue-50 hover:bg-blue-100 text-blue-900 p-4 rounded-xl flex items-center gap-4 transition-all group border border-blue-200">
            <div className="bg-blue-600 text-white p-3 rounded-full group-hover:scale-110 transition-transform">
              <User size={24} />
            </div>
            <div className="text-left">
              <h3 className="font-bold text-lg">続きから編集</h3>
              <p className="text-xs text-gray-500">前回のデータを編集または確認します</p>
            </div>
            <ChevronRight className="ml-auto text-blue-400" />
          </button>

          <button onClick={onNew} className="w-full bg-green-50 hover:bg-green-100 text-green-900 p-4 rounded-xl flex items-center gap-4 transition-all group border border-green-200">
            <div className="bg-green-600 text-white p-3 rounded-full group-hover:scale-110 transition-transform">
              <Plus size={24} />
            </div>
            <div className="text-left">
              <h3 className="font-bold text-lg">新規評価を作成</h3>
              <p className="text-xs text-gray-500">このスタッフの新しい評価を作成します</p>
            </div>
            <ChevronRight className="ml-auto text-green-400" />
          </button>

          <button onClick={onHistory} className="w-full bg-purple-50 hover:bg-purple-100 text-purple-900 p-4 rounded-xl flex items-center gap-4 transition-all group border border-purple-200">
            <div className="bg-purple-600 text-white p-3 rounded-full group-hover:scale-110 transition-transform">
              <History size={24} />
            </div>
            <div className="text-left">
              <h3 className="font-bold text-lg">履歴一覧を確認</h3>
              <p className="text-xs text-gray-500">過去の評価履歴を表示・比較します</p>
            </div>
            <ChevronRight className="ml-auto text-purple-400" />
          </button>
        </div>
      </div>
    </div>
  );
};
